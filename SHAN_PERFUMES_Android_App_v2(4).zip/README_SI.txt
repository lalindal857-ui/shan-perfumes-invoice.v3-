SHAN PERFUMES Android App v3.0

ප්‍රධාන විශේෂාංග:
- Portrait සහ Landscape phone layout
- Dark Mode සහ Light Mode
- SHAN Silver Crown Logo, splash screen සහ launcher icon
- Products & Stock, Customers, Sales & Orders
- Invoice preview, print / PDF
- Invoice heading, footer, accent colour සහ business details customize කිරීම
- JSON backup / restore
- Offline local storage

Build:
GitHub Actions workflow එකෙන් Java 17 සහ Gradle 8.9 භාවිතා කර assembleDebug build කරන්න.

වැදගත්:
මෙම version එකේ දත්ත එක් එක් phone එකේ local storage තුළ පමණක් ගබඩා වේ. Phones කිහිපයක් අතර real-time sync සඳහා cloud backend/login system එකක් වෙනම අවශ්‍ය වේ. PDF printing සහ backup/restore ක්‍රියාකාරිත්වය Android device එකක install කර පරීක්ෂා කළ යුතුය.
